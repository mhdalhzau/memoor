export const base_path = "/react/template/";
// export const base_path = "/";
