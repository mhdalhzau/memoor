export const salestransaction = [
	{
		id: 1,
		"orderdetails": "Lobar Handy\n    15 Mins",
		"payment": "Paypal\n  #416645453773",
		"status": "Success",
		"amount": "$1,099.00"
	},
	{
		id: 2,
		"orderdetails": "Red Premium Handy\n    10 Mins",
		"payment": "Apple Pay\n  #147784454554",
		"status": "Canceled",
		"amount": "$600.55"
	},
	{
		id: 3,
		"orderdetails": "Iphone 14 Pro\n    10 Mins",
		"payment": "Stripe\n  #147784454554",
		"status": "Pending",
		"amount": "$1,099.00"
	},
	{
		id: 4,
		"orderdetails": "Black Slim 200\n    10 Mins",
		"payment": "PayU\n  #147784454554",
		"status": "Success",
		"amount": "$1,569.00"
	},
	{
		id: 5,
		"orderdetails": "Woodcraft Sandal\n    15 Mins",
		"payment": "Paytm\n  #147784454554",
		"status": "Success",
		"amount": "$1,478.00"
	}
]